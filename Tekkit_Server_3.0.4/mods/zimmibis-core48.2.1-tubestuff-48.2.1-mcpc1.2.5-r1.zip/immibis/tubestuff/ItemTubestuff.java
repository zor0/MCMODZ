package immibis.tubestuff;

import immibis.core.ItemCombined;

public class ItemTubestuff extends ItemCombined
{
    public ItemTubestuff(int var1)
    {
        super(var1, new String[] {"Buffer", "Automatic Crafting Table MkII", "Black Hole Chest"});
    }
}
