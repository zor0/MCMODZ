package immibis.core.covers;

public enum EnumPositionClass
{
    Centre,
    Face,
    Edge,
    Corner,
    Post;
}
