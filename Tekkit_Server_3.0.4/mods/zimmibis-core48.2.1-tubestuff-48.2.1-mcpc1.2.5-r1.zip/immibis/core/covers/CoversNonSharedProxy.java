package immibis.core.covers;

public class CoversNonSharedProxy
{
    static void RegisterHighlightHandler() {}
}
