package immibis.core.covers;

public interface ICoverableBlock
{
}
