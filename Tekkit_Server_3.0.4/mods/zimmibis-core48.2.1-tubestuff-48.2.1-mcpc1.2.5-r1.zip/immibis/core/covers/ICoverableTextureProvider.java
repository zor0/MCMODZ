package immibis.core.covers;

public interface ICoverableTextureProvider
{
    String getTextureFile();
}
