package immibis.core.covers;

public interface ICoverableTile
{
    CoverImpl getCoverImpl();
}
