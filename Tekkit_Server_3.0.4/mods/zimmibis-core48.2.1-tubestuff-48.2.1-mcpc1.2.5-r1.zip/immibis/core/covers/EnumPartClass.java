package immibis.core.covers;

public enum EnumPartClass
{
    Centre,
    Panel,
    HollowPanel,
    Strip,
    Corner;
}
