package immibis.core.config;

public interface IConfigReader
{
    String getConfigEntry(String var1);
}
