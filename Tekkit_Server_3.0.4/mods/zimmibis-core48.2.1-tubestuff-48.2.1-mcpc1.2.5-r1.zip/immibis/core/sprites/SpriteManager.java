package immibis.core.sprites;

public class SpriteManager
{
}
