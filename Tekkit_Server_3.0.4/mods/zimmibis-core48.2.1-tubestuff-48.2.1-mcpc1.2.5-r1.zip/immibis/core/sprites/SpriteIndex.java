package immibis.core.sprites;

public class SpriteIndex
{
    public final String file;
    public final int index;

    public SpriteIndex(String var1, int var2)
    {
        this.file = var1;
        this.index = var2;
    }
}
