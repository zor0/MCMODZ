package immibis.core;

public interface IBlockIDCallback
{
    void registerBlock(int var1);
}
