// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TileEntityChargingBench1.java

package ic2chargingbench.common;


// Referenced classes of package ic2chargingbench.common:
//            TileEntityChargingBench

public class TileEntityChargingBench1 extends TileEntityChargingBench
{

    public TileEntityChargingBench1()
    {
        super(1);
    }
}
