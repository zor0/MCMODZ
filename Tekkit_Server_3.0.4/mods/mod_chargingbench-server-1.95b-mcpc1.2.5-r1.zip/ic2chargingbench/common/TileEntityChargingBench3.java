// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TileEntityChargingBench3.java

package ic2chargingbench.common;


// Referenced classes of package ic2chargingbench.common:
//            TileEntityChargingBench

public class TileEntityChargingBench3 extends TileEntityChargingBench
{

    public TileEntityChargingBench3()
    {
        super(3);
    }
}
